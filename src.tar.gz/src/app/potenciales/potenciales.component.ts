import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-potenciales',
  templateUrl: './potenciales.component.html',
  styleUrls: ['./potenciales.component.css']
})
export class PotencialesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
