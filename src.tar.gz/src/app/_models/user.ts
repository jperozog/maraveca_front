import { Injectable } from '@angular/core';

@Injectable()
export class User {
    public id_user: number;
    public username: string;
    public password_user: string;
    public nombre_user: string;
    public apellido_user: string;
    public email_user: string;
    public phone_user: string;
}
export class perm {
  public perm= [];
}
