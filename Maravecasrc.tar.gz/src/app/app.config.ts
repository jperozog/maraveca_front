import { OpaqueToken } from "@angular/core";
import {IAppConfig} from "./app.interface";

export let APP_CONFIG = new OpaqueToken("app.config");
