import { CapitalizePipe2 } from './capitalize.pipe';

describe('CapitalizePipe', () => {
  it('create an instance', () => {
    const pipe = new CapitalizePipe2();
    expect(pipe).toBeTruthy();
  });
});
