import {
  Component,
  Pipe,
  PipeTransform
} from '@angular/core';
import { Http } from '@angular/http';

//import dataPipe from './layout.component.ts'


@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css']
})
export class LayoutComponent {
  
}
